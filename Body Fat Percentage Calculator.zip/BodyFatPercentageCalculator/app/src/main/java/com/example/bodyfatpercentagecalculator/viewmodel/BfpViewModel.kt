package com.example.bodyfatpercentagecalculator.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bodyfatpercentagecalculator.model.BfpCalculationInput
import com.example.bodyfatpercentagecalculator.model.BfpCalculationResult
import com.example.bodyfatpercentagecalculator.model.Gender
import com.example.bodyfatpercentagecalculator.repository.BfpRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class BfpViewModel @Inject constructor(
    private val repository: BfpRepository
) : ViewModel() {

    private val _calculationResult = MutableLiveData<BfpCalculationResult?>()
    val calculationResult: LiveData<BfpCalculationResult?> = _calculationResult

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    fun calculateBfp(
        weightText: String,
        heightText: String,
        ageText: String,
        selectedGender: Gender?
    ) {
        try {
            // Validate inputs
            val weight = weightText.toDoubleOrNull()
            val height = heightText.toDoubleOrNull()
            val age = ageText.toIntOrNull()

            when {
                weight == null || weight <= 0 -> {
                    _errorMessage.value = "Masukkan berat badan yang valid"
                    return
                }
                height == null || height <= 0 -> {
                    _errorMessage.value = "Masukkan tinggi badan yang valid"
                    return
                }
                age == null || age <= 0 -> {
                    _errorMessage.value = "Masukkan usia yang valid"
                    return
                }
                selectedGender == null -> {
                    _errorMessage.value = "Pilih jenis kelamin"
                    return
                }
            }

            // Clear any previous error
            _errorMessage.value = null

            // Create input and calculate
            val input = BfpCalculationInput(
                weight = weight,
                height = height,
                age = age,
                gender = selectedGender
            )

            val result = repository.calculateBfp(input)
            _calculationResult.value = result

        } catch (e: Exception) {
            _errorMessage.value = "Terjadi kesalahan: ${e.message}"
        }
    }

    fun clearResult() {
        _calculationResult.value = null
        _errorMessage.value = null
    }
} 