package com.example.bodyfatpercentagecalculator.repository

import com.example.bodyfatpercentagecalculator.model.BfpCalculationInput
import com.example.bodyfatpercentagecalculator.model.BfpCalculationResult
import com.example.bodyfatpercentagecalculator.model.BfpCategory
import com.example.bodyfatpercentagecalculator.model.Gender
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BfpRepository @Inject constructor() {

    fun calculateBfp(input: BfpCalculationInput): BfpCalculationResult {
        // Calculate BMI first
        val heightInMeters = input.height / 100.0
        val bmi = input.weight / (heightInMeters * heightInMeters)
        
        // Calculate BFP based on gender
        val bfp = when (input.gender) {
            Gender.MALE -> (1.20 * bmi) + (0.23 * input.age) - 16.2
            Gender.FEMALE -> (1.20 * bmi) + (0.23 * input.age) - 5.4
        }
        
        // Determine category
        val category = when {
            bfp < 10 -> BfpCategory.VERY_LOW
            bfp in 10.0..20.0 -> BfpCategory.LOW
            bfp in 21.0..25.0 -> BfpCategory.NORMAL
            bfp in 26.0..30.0 -> BfpCategory.HIGH
            else -> BfpCategory.VERY_HIGH
        }
        
        return BfpCalculationResult(
            bmi = bmi,
            bfp = bfp,
            category = category
        )
    }
} 