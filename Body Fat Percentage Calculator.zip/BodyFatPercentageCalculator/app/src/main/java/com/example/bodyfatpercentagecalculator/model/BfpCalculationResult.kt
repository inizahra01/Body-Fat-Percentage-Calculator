package com.example.bodyfatpercentagecalculator.model

data class BfpCalculationResult(
    val bmi: Double,
    val bfp: Double,
    val category: BfpCategory
)

enum class BfpCategory(val description: String) {
    VERY_LOW("Sangat Rendah"),
    LOW("Rendah"),
    NORMAL("Normal"),
    HIGH("Tinggi"),
    VERY_HIGH("Sangat Tinggi")
} 