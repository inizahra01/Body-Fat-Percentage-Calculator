package com.example.bodyfatpercentagecalculator

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bodyfatpercentagecalculator.databinding.ActivityMainBinding
import com.example.bodyfatpercentagecalculator.model.Gender
import com.example.bodyfatpercentagecalculator.viewmodel.BfpViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.text.DecimalFormat

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val viewModel: BfpViewModel by viewModels()
    private val decimalFormat = DecimalFormat("#.##")
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        setupClickListeners()
        observeViewModel()
    }
    
    private fun setupClickListeners() {
        binding.btnCalculate.setOnClickListener {
            calculateBfp()
        }
        
        binding.btnClear.setOnClickListener {
            clearForm()
        }
    }
    
    private fun calculateBfp() {
        val selectedGender = when (binding.rgGender.checkedRadioButtonId) {
            binding.rbMale.id -> Gender.MALE
            binding.rbFemale.id -> Gender.FEMALE
            else -> null
        }
        
        viewModel.calculateBfp(
            weightText = binding.etWeight.text.toString(),
            heightText = binding.etHeight.text.toString(),
            ageText = binding.etAge.text.toString(),
            selectedGender = selectedGender
        )
    }
    
    private fun observeViewModel() {
        viewModel.calculationResult.observe(this) { result ->
            if (result != null) {
                binding.cardResult.visibility = android.view.View.VISIBLE
                binding.tvBmiResult.text = "BMI: ${decimalFormat.format(result.bmi)}"
                binding.tvBfpResult.text = "BFP: ${decimalFormat.format(result.bfp)}%"
                binding.tvCategoryResult.text = "Kategori: ${result.category.description}"
                
                // Set category color
                val categoryColor = when (result.category) {
                    com.example.bodyfatpercentagecalculator.model.BfpCategory.VERY_LOW -> 
                        androidx.core.content.ContextCompat.getColor(this, android.R.color.holo_blue_light)
                    com.example.bodyfatpercentagecalculator.model.BfpCategory.LOW -> 
                        androidx.core.content.ContextCompat.getColor(this, android.R.color.holo_green_light)
                    com.example.bodyfatpercentagecalculator.model.BfpCategory.NORMAL -> 
                        androidx.core.content.ContextCompat.getColor(this, android.R.color.holo_green_dark)
                    com.example.bodyfatpercentagecalculator.model.BfpCategory.HIGH -> 
                        androidx.core.content.ContextCompat.getColor(this, android.R.color.holo_orange_light)
                    com.example.bodyfatpercentagecalculator.model.BfpCategory.VERY_HIGH -> 
                        androidx.core.content.ContextCompat.getColor(this, android.R.color.holo_red_light)
                }
                binding.tvCategoryResult.setTextColor(categoryColor)
            } else {
                binding.cardResult.visibility = android.view.View.GONE
            }
        }
        
        viewModel.errorMessage.observe(this) { error ->
            if (error != null) {
                binding.tvError.text = error
                binding.tvError.visibility = android.view.View.VISIBLE
            } else {
                binding.tvError.visibility = android.view.View.GONE
            }
        }
    }
    
    private fun clearForm() {
        binding.etWeight.text?.clear()
        binding.etHeight.text?.clear()
        binding.etAge.text?.clear()
        binding.rgGender.clearCheck()
        viewModel.clearResult()
    }
}