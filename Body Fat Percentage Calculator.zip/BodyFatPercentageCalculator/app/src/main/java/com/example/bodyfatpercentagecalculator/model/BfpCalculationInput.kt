package com.example.bodyfatpercentagecalculator.model

data class BfpCalculationInput(
    val weight: Double, // kg
    val height: Double, // cm
    val age: Int,
    val gender: Gender
)

enum class Gender {
    MALE, FEMALE
} 